# CRAWFORDS — read-only Solana website

A static, mobile-friendly website and token dashboard for the Solana mint `4hqbFGLWrHd3tbCK96gsrziKG3eS8r9MAgGeLgnmzray`.

## Run locally

Open `index.html` in a browser, or serve the folder with `python3 -m http.server 8000` and visit `http://localhost:8000`.

## Deploy

Deploy the folder to any static hosting service (e.g. Vercel static site). No environment variables, private keys, or wallet credentials are needed.

## Security and limitations

- Read-only JSON-RPC methods: `getTokenSupply` and `getTokenLargestAccounts`.
- No wallet connection, signing, transactions, trading, transfers, or payments.
- Public Solana RPC may throttle requests or reject some browser requests; failures are displayed honestly.
- The largest-accounts metric is the count of nonzero accounts among the returned top 20, **not** a unique-holder count.
- Mint/freeze authority details are **not verified** in this prototype.
- No invented price, market cap, liquidity, or holder statistics.
- Review UK financial-promotion rules and publish transparent tokenomics before public marketing.
